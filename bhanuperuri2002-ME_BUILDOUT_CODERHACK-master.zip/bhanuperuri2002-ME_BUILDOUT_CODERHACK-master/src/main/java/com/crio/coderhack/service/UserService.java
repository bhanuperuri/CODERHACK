package com.crio.coderhack.service;

import java.util.List;
import com.crio.coderhack.dto.ScoreUpdateDto;
import com.crio.coderhack.dto.UserRequestDto;
import com.crio.coderhack.entity.User;

public interface UserService {
    
    User createUser(UserRequestDto request);
    User getUser(String userId);
    User updateScore(String userId, ScoreUpdateDto score);
    List<User> getAllUsersSortedByScore();
    void deleteUser(String userId);

}