package com.crio.coderhack.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScoreUpdateDto {

    @Min(0)
    @Max(100)
    private int score;
    
}
