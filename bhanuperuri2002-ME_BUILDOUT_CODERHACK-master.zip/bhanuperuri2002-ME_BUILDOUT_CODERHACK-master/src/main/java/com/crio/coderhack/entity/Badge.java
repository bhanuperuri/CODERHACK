package com.crio.coderhack.entity;

public enum Badge {
    CODE_NINJA,
    CODE_CHAMP,
    CODE_MASTER
}