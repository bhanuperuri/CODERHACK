package com.crio.coderhack.controller;

import lombok.RequiredArgsConstructor;
import java.util.List;
import com.crio.coderhack.dto.ScoreUpdateDto;
import com.crio.coderhack.dto.UserRequestDto;
import com.crio.coderhack.entity.User;
import com.crio.coderhack.service.UserService;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/coderhack/api/v1/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public User createUser(@Valid @RequestBody UserRequestDto request) {
        return userService.createUser(request);
    }

    @GetMapping("/{userId}")
    public User getUser(@PathVariable String userId) {
        return userService.getUser(userId);
    }

    @PutMapping("/{userId}")
    public User updateScore(@PathVariable String userId, @Valid @RequestBody ScoreUpdateDto dto) {
        return userService.updateScore(userId, dto);
    }

    @GetMapping
    public List<User> getAllUsersSorted() {
        return userService.getAllUsersSortedByScore();
    }

    @DeleteMapping("/{userId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUser(@PathVariable String userId) {
        userService.deleteUser(userId);
    }
}
