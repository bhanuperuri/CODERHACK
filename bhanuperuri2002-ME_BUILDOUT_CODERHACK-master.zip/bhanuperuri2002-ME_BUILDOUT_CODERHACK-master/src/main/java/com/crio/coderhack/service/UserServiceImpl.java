package com.crio.coderhack.service;

import lombok.RequiredArgsConstructor;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.crio.coderhack.dto.ScoreUpdateDto;
import com.crio.coderhack.dto.UserRequestDto;
import com.crio.coderhack.entity.Badge;
import com.crio.coderhack.entity.User;
import com.crio.coderhack.repository.UserRepository;
import org.springframework.stereotype.Service;
import javax.validation.Valid;

import java.util.*;


@Service
@RequiredArgsConstructor


public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    
    @Override
    public User createUser(@Valid UserRequestDto request) {
        if (userRepository.existsById(request.getUserId())) {
            throw new IllegalArgumentException("User ID already exists");
        }
        User user = User.builder()
                .userId(request.getUserId())
                .username(request.getUsername())
                .score(0)
                .badges(new HashSet<>())
                .build();
        return userRepository.save(user);
    }

    @Override
    public User getUser(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
    }

    @Override
    public User updateScore(String userId, @Valid ScoreUpdateDto dto) {
        User user = getUser(userId);

        user.setScore(dto.getScore());
        assignBadges(user);

        return userRepository.save(user);
    }

private void assignBadges(User user) {
    Set<Badge> badges = new HashSet<>();
    int score = user.getScore();

    if (score >= 1) { 
        badges.add(Badge.CODE_NINJA);
    }
    if (score >= 30) {
        badges.add(Badge.CODE_CHAMP);
    }
    if (score >= 60) {
        badges.add(Badge.CODE_MASTER);
    }

    user.setBadges(badges);
}

@Override
public List<User> getAllUsersSortedByScore() {
    List<User> users = userRepository.findAll();
    users.sort(Comparator.comparingInt(User::getScore).reversed()); // Descending
    return users;
}

    @Override
    public void deleteUser(String userId) {
        if (!userRepository.existsById(userId)) {
            throw new NoSuchElementException("User not found");
        }
        userRepository.deleteById(userId);
    }

    
}